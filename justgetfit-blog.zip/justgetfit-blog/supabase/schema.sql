-- =====================================================
-- justgetfit.com — Full CMS schema
-- Run this in Supabase SQL Editor on a fresh project
-- =====================================================

-- TOPICS: pool of post ideas the cron picks from
create table if not exists topics (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null,
  angle text,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

-- DRAFTS: AI-generated posts awaiting review
create table if not exists drafts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null,
  excerpt text,
  content text not null,
  category text,
  cover_image_url text,
  cover_image_credit text,
  topic_id uuid references topics(id) on delete set null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  generation_model text,
  generation_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- POSTS: published articles
create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  excerpt text,
  content text not null,
  category text,
  cover_image_url text,
  cover_image_credit text,
  draft_id uuid references drafts(id) on delete set null,
  read_minutes integer,
  published_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- SITE SETTINGS: key-value store for global site configuration
create table if not exists settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

-- PAGES: structured CMS content for static pages (about, subscribe, contact, home-hero)
create table if not exists pages (
  slug text primary key,
  content jsonb not null,
  updated_at timestamptz not null default now()
);

-- NAV ITEMS: ordered menu items for nav and footer
create table if not exists nav_items (
  id uuid primary key default gen_random_uuid(),
  location text not null check (location in ('main_nav', 'footer_quick_links', 'footer_categories')),
  label text not null,
  url text not null,
  is_cta boolean not null default false,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- PARTNERS: cards on the /partners page
create table if not exists partners (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  blurb text not null,
  url text not null,
  tag text,
  image_url text,
  image_gradient text,
  initials text,
  position integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- CATEGORIES: editable category list
create table if not exists categories (
  slug text primary key,
  name text not null,
  icon text,
  position integer not null default 0,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- CONTACT MESSAGES: stored copies of contact form submissions
create table if not exists contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  subject text,
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

-- SUBSCRIBERS: newsletter list
create table if not exists subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  status text not null default 'pending' check (status in ('pending', 'confirmed', 'unsubscribed', 'bounced')),
  confirmation_token text not null,
  unsubscribe_token text not null,
  source text,
  subscribed_at timestamptz not null default now(),
  confirmed_at timestamptz,
  unsubscribed_at timestamptz,
  last_sent_at timestamptz
);

-- NEWSLETTER SENDS: log of every blast
create table if not exists newsletter_sends (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references posts(id) on delete cascade,
  sent_at timestamptz not null default now(),
  recipient_count integer not null default 0,
  failed_count integer not null default 0,
  status text not null default 'pending' check (status in ('pending', 'sending', 'completed', 'failed')),
  notes text
);

-- INDEXES
create index if not exists idx_posts_published_at on posts (published_at desc);
create index if not exists idx_posts_slug on posts (slug);
create index if not exists idx_posts_category on posts (category);
create index if not exists idx_drafts_status on drafts (status);
create index if not exists idx_drafts_created_at on drafts (created_at desc);
create index if not exists idx_topics_used_at on topics (used_at);
create index if not exists idx_partners_position on partners (position);
create index if not exists idx_nav_items_location on nav_items (location, sort_order);
create index if not exists idx_categories_position on categories (position);
create index if not exists idx_contact_created_at on contact_messages (created_at desc);
create index if not exists idx_subscribers_status on subscribers (status);
create index if not exists idx_subscribers_email on subscribers (email);
create index if not exists idx_subscribers_confirmation_token on subscribers (confirmation_token);
create index if not exists idx_subscribers_unsubscribe_token on subscribers (unsubscribe_token);
create index if not exists idx_newsletter_sends_post_id on newsletter_sends (post_id);

-- AUTO UPDATED_AT TRIGGER
create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists drafts_updated_at on drafts;
create trigger drafts_updated_at before update on drafts
  for each row execute function set_updated_at();

drop trigger if exists posts_updated_at on posts;
create trigger posts_updated_at before update on posts
  for each row execute function set_updated_at();

drop trigger if exists settings_updated_at on settings;
create trigger settings_updated_at before update on settings
  for each row execute function set_updated_at();

drop trigger if exists pages_updated_at on pages;
create trigger pages_updated_at before update on pages
  for each row execute function set_updated_at();

drop trigger if exists nav_items_updated_at on nav_items;
create trigger nav_items_updated_at before update on nav_items
  for each row execute function set_updated_at();

drop trigger if exists partners_updated_at on partners;
create trigger partners_updated_at before update on partners
  for each row execute function set_updated_at();

-- ROW LEVEL SECURITY
alter table posts             enable row level security;
alter table drafts            enable row level security;
alter table topics            enable row level security;
alter table settings          enable row level security;
alter table pages             enable row level security;
alter table nav_items         enable row level security;
alter table partners          enable row level security;
alter table categories        enable row level security;
alter table contact_messages  enable row level security;
alter table subscribers       enable row level security;
alter table newsletter_sends  enable row level security;

-- Public read policies
drop policy if exists "Public read posts" on posts;
create policy "Public read posts" on posts for select using (true);

drop policy if exists "Public read settings" on settings;
create policy "Public read settings" on settings for select using (true);

drop policy if exists "Public read pages" on pages;
create policy "Public read pages" on pages for select using (true);

drop policy if exists "Public read active nav_items" on nav_items;
create policy "Public read active nav_items" on nav_items for select using (active = true);

drop policy if exists "Public read active partners" on partners;
create policy "Public read active partners" on partners for select using (is_active = true);

drop policy if exists "Public read active categories" on categories;
create policy "Public read active categories" on categories for select using (is_active = true);

-- =====================================================
-- DEFAULT CATEGORIES (8 — including Mindset)
-- =====================================================
insert into categories (slug, name, icon, position, description) values
  ('strength',     'Strength',     '⚡', 0, 'Getting strong: barbell training, progressive overload, the big lifts.'),
  ('hypertrophy',  'Hypertrophy',  '▲', 1, 'Building muscle: volume, intensity, and the stuff that drives growth.'),
  ('conditioning', 'Conditioning', '♥', 2, 'Cardio, work capacity, and the stuff that keeps you breathing.'),
  ('nutrition',    'Nutrition',    '●', 3, 'What to eat, when to eat, and what actually moves the needle.'),
  ('recovery',     'Recovery',     '◐', 4, 'Sleep, deloads, fatigue management — how rest builds the gains.'),
  ('mobility',     'Mobility',     '↻', 5, 'Joint health, range of motion, and what actually works.'),
  ('programming',  'Programming',  '⚙', 6, 'How to design training that actually progresses you week to week.'),
  ('mindset',      'Mindset',      '✦', 7, 'The mental game: motivation, discipline, habits, consistency.')
on conflict (slug) do nothing;

-- =====================================================
-- DEFAULT SETTINGS
-- =====================================================
insert into settings (key, value) values
  ('site', '{
    "name": "Just Get Fit",
    "tagline": "Stronger. Every day.",
    "description": "Evidence-based fitness writing on training, nutrition, recovery, and the long game.",
    "contact_email": "hello@justgetfit.com",
    "newsletter_enabled": true
  }'::jsonb),
  ('footer', '{
    "brand_tagline": "Evidence-based fitness writing on training, nutrition, recovery, and the long game. New article every Monday — stronger, every day.",
    "copyright": "© 2026 Just Get Fit. Stronger. Every day. Nothing here is medical advice.",
    "version_label": "v1.0"
  }'::jsonb)
on conflict (key) do nothing;

-- =====================================================
-- DEFAULT PAGES
-- =====================================================
insert into pages (slug, content) values
  ('home-hero', '{
    "pill_text": "New article every Monday · Evidence-based",
    "headline_part1": "Stronger.",
    "headline_accent": "Every",
    "headline_part2": "day.",
    "lede": "Just Get Fit is evidence-based fitness writing that cuts through the noise. Strength, hypertrophy, conditioning, nutrition, recovery — one fresh article every Monday. No supplement shilling. No miracle protocols. Just what works.",
    "cta_primary": { "label": "Read the latest", "url": "/articles" },
    "cta_secondary": { "label": "Browse categories", "url": "/categories" },
    "background_image_url": "",
    "stats": [
      { "num": "auto:posts", "suffix": "", "label": "Articles live" },
      { "num": "auto:categories", "suffix": "", "label": "Categories" },
      { "num": "Weekly", "suffix": "", "label": "Mondays, 9am" },
      { "num": "No Hype", "suffix": "", "label": "Just Facts" }
    ]
  }'::jsonb),
  ('about', '{
    "pill_text": "About Just Get Fit",
    "headline_part1": "Stronger.",
    "headline_accent": "Every",
    "headline_part2": "day. That''s the whole thing.",
    "tagline": "No miracle protocols. No supplement affiliate links. No \"one weird trick\" headlines. Just evidence-based fitness writing — published every Monday, for people who train.",
    "body_markdown": "## What we cover\n\nJust Get Fit publishes one article every Monday across eight categories: **strength, hypertrophy, conditioning, nutrition, recovery, mobility, programming, and mindset**. Topics rotate so you''re not getting the same thing every week.\n\n## How we publish\n\nEvery article goes through a careful editorial process: **researched, drafted, reviewed, and edited** before anything ships. Nothing goes live without being read twice. If something is wrong, fabricated, or just bad — tell us. We''d rather fix it than be wrong on the internet.\n\n## Our publishing schedule\n\nOne new article every Monday at 9am Eastern. The article is selected from a rotating list of topics across all eight categories — meaning if you read every Monday for a year, you''ll get a balanced curriculum across strength, nutrition, recovery, and the rest.\n\nYou can subscribe to the newsletter to get each new article delivered to your inbox — or just bookmark the site.",
    "pillars": [
      { "num": "01", "title": "Evidence first", "desc": "If we cite a claim, it''s grounded in research. If the research is mixed, we say so." },
      { "num": "02", "title": "Practical takeaways", "desc": "Every article ends with what you can actually do this week. No theory without application." },
      { "num": "03", "title": "No bullshit", "desc": "No supplement shilling. No clickbait. No advice that ignores ordinary humans with jobs and bad knees." }
    ],
    "cta_primary": { "label": "Subscribe to the newsletter", "url": "/subscribe" },
    "cta_secondary": { "label": "Read latest →", "url": "/articles" }
  }'::jsonb),
  ('subscribe', '{
    "pill_text": "Free · One email per week",
    "headline_part1": "Get every article",
    "headline_accent": "in your inbox",
    "headline_part2": ".",
    "lede": "One email every Monday morning with the latest article. No spam. No upsells. No \"transformation challenges\". Unsubscribe anytime in one click.",
    "form_placeholder": "you@example.com",
    "form_button": "Subscribe →",
    "promise_heading": "What you''ll get",
    "promises": [
      { "icon": "📅", "title": "Every Monday at 9am", "desc": "One article delivered the morning it goes live. Set your week up right." },
      { "icon": "📚", "title": "All eight categories",  "desc": "Strength, hypertrophy, conditioning, nutrition, recovery, mobility, programming, mindset — rotating." },
      { "icon": "🔬", "title": "Evidence-based",        "desc": "If we make a claim it''s backed by research. If the research is mixed, we say so." },
      { "icon": "🚫", "title": "No spam, ever",         "desc": "One email a week. That''s it. No supplement pitches. No course funnels. No nonsense." }
    ],
    "faq_heading": "Common questions",
    "faqs": [
      { "q": "Is it really free?", "a": "Yes. The newsletter is free and there are no plans to put it behind a paywall. If we ever introduce paid content it''ll be additive — the weekly article will always be free." },
      { "q": "How do I unsubscribe?", "a": "Every email has a one-click unsubscribe link at the bottom. No confirmation, no \"are you sure\", no exit survey. You click it and you''re out." },
      { "q": "Will you sell my email?", "a": "No. Your email goes into the newsletter platform and nowhere else. We don''t sell, share, or rent email lists." },
      { "q": "What if I miss a week?", "a": "Every article also lives on the site permanently — just bookmark [/articles](/articles) and you can catch up anytime." }
    ]
  }'::jsonb),
  ('contact', '{
    "pill_text": "Contact",
    "headline_part1": "Get in",
    "headline_accent": "touch",
    "headline_part2": ".",
    "intro": "Questions, feedback, or you spotted something wrong in an article? Drop us a line. We read every email.",
    "labels": {
      "name": "Your name",
      "email": "Email",
      "subject": "Subject",
      "message": "Message",
      "submit": "Send message →"
    },
    "placeholders": {
      "name": "Jane Doe",
      "email": "jane@example.com",
      "subject": "What''s this about?",
      "message": "Type your message..."
    },
    "success_message": "Got it. We''ll get back to you within a few days."
  }'::jsonb)
on conflict (slug) do nothing;

-- =====================================================
-- DEFAULT NAV ITEMS
-- =====================================================
insert into nav_items (location, label, url, is_cta, sort_order) values
  ('main_nav', 'About Us',   '/about',     false, 0),
  ('main_nav', 'Categories', '/categories', false, 1),
  ('main_nav', 'Partners',   '/partners',  false, 2),
  ('main_nav', 'Contact Us', '/contact',   false, 3),
  ('main_nav', 'Subscribe',  '/subscribe', true,  4),
  ('footer_quick_links', 'About Us',   '/about',     false, 0),
  ('footer_quick_links', 'Categories', '/categories', false, 1),
  ('footer_quick_links', 'Partners',   '/partners',  false, 2),
  ('footer_quick_links', 'Contact Us', '/contact',   false, 3),
  ('footer_quick_links', 'Subscribe',  '/subscribe', false, 4),
  ('footer_categories', 'Strength',     '/category/strength',     false, 0),
  ('footer_categories', 'Recovery',     '/category/recovery',     false, 1),
  ('footer_categories', 'Hypertrophy',  '/category/hypertrophy',  false, 2),
  ('footer_categories', 'Mobility',     '/category/mobility',     false, 3),
  ('footer_categories', 'Nutrition',    '/category/nutrition',    false, 4),
  ('footer_categories', 'Programming',  '/category/programming',  false, 5),
  ('footer_categories', 'Conditioning', '/category/conditioning', false, 6),
  ('footer_categories', 'Mindset',      '/category/mindset',      false, 7)
on conflict do nothing;

-- =====================================================
-- DEFAULT PARTNERS
-- =====================================================
insert into partners (name, blurb, url, tag, image_gradient, initials, position) values
  ('OutlawFighters.com',       'Combat sports coverage, fight breakdowns, and training content for boxers, MMA fighters, and grapplers. Our other publication.', 'https://outlawfighters.com',    'Sister Site',         'linear-gradient(135deg, #1a0303 0%, #4a0808 50%, #8b1a1a 100%)', '⚔ OUTLAW', 0),
  ('Renaissance Periodization','Dr. Mike Israetel and team. The gold standard for evidence-based hypertrophy and strength training education.',                  'https://rpstrength.com',        'Recommended Reading', 'linear-gradient(135deg, #0a3d0a 0%, #1a6b1a 50%, #2d9b2d 100%)', 'RP', 1),
  ('Stronger By Science',      'Greg Nuckols'' research-backed strength site. Deep dives on the latest exercise science studies, no fluff.',                       'https://strongerbyscience.com', 'Recommended Reading', 'linear-gradient(135deg, #2c2c2e 0%, #4a4a4d 50%, #6a6a6d 100%)', 'SBS', 2),
  ('Rogue Fitness',            'Where most of our home-gym recommendations live. Bars, plates, racks, kettlebells — built to last.',                              'https://roguefitness.com',      'Tools',               'linear-gradient(135deg, #1a1a3e 0%, #2d2d6b 50%, #4949a8 100%)', 'RG', 3),
  ('Eight Sleep',              'A mattress that actively cools and warms while you sleep. We mention sleep a lot — this is the gear behind that.',               'https://eightsleep.com',        'App',                 'linear-gradient(135deg, #4a1a3d 0%, #6b2d5a 50%, #a8497d 100%)', 'EL', 4),
  ('MacroFactor',              'The nutrition tracking app from Stronger By Science. Smartest macro coach available — actually adapts to your data.',           'https://macrofactorapp.com',    'App',                 'linear-gradient(135deg, #3d2c0a 0%, #6b4a1a 50%, #a87a2d 100%)', 'MQ', 5)
on conflict do nothing;

-- =====================================================
-- SEED TOPIC QUEUE (rotating ideas for cron)
-- =====================================================
insert into topics (title, category, angle) values
  ('The 5×5 method: why it still works after 60 years', 'strength', 'historical + practical breakdown'),
  ('How much protein do you actually need?', 'nutrition', 'evidence-based myth-busting'),
  ('Why your warm-up is probably wasting your time', 'programming', 'contrarian take on dynamic warm-ups'),
  ('Sleep is the most underrated supplement', 'recovery', 'sleep science for lifters'),
  ('Cardio for people who hate cardio', 'conditioning', 'low-effort high-yield options'),
  ('The case for training to failure (sometimes)', 'strength', 'nuanced look at RPE and intensity'),
  ('Mobility vs flexibility: stop confusing them', 'mobility', 'definitions + practical routine'),
  ('Why deload weeks beat training through fatigue', 'strength', 'recovery and supercompensation'),
  ('Caffeine timing for workouts: the 45-minute rule', 'nutrition', 'pharmacokinetics made simple'),
  ('Compound lifts that aren''t the big three', 'strength', 'underrated pulls and presses'),
  ('How to actually progress on bodyweight training', 'programming', 'progression schemes for calisthenics'),
  ('The minimum effective dose for muscle growth', 'hypertrophy', 'lowest volume that still works'),
  ('Walking is underrated. Here''s the data.', 'conditioning', 'NEAT and longevity research'),
  ('Why you keep tweaking your lower back', 'recovery', 'common causes + brace patterns'),
  ('Creatine: still the most boring, most reliable supplement', 'nutrition', 'evidence summary, no hype'),
  ('The 80/20 of fat loss', 'nutrition', 'what actually moves the needle'),
  ('Grip training that actually carries over', 'hypertrophy', 'beyond fat-grip curls'),
  ('How to write a training program for yourself', 'programming', 'frameworks not templates'),
  ('Tempo work: when slow reps actually help', 'hypertrophy', 'eccentric overload + technique'),
  ('Why your shoulders hurt when you bench', 'recovery', 'setup, scap position, programming'),
  ('Heart rate zones for normal humans', 'conditioning', 'demystifying zone 2'),
  ('The "perfect" rep doesn''t exist', 'programming', 'when form variability is fine'),
  ('Training around an injury without losing progress', 'recovery', 'modification frameworks'),
  ('Why most stretching research is mixed', 'mobility', 'what the studies actually show'),
  ('Building a home gym for under $500', 'strength', 'minimum viable equipment'),
  ('The squat depth debate is mostly silly', 'strength', 'biomechanics + individual variation'),
  ('Sodium, potassium, and the cramp myth', 'nutrition', 'electrolytes for athletes'),
  ('Push, pull, legs: the most overrated split', 'programming', 'when it works, when it doesn''t'),
  ('Single-leg training: more than just rehab', 'strength', 'unilateral work for everyone'),
  ('What your morning resting heart rate tells you', 'recovery', 'HRV and overtraining signals'),
  ('Time under tension is mostly marketing', 'hypertrophy', 'what actually drives growth'),
  ('Detraining: how fast you actually lose gains', 'programming', 'research on layoffs'),
  ('Plyometrics for non-athletes', 'conditioning', 'jumping for general fitness'),
  ('Coffee, tea, and pre-workout: what''s the real difference', 'nutrition', 'stimulant comparison'),
  ('Training fasted: pros, cons, and considerations', 'nutrition', 'evidence + n=1 considerations'),
  ('How to deload without losing your mind', 'mindset', 'mental side of taking it easy'),
  ('The myth of muscle confusion', 'programming', 'why you don''t need constant variety'),
  ('Lifting after 40: what changes and what doesn''t', 'programming', 'aging and training'),
  ('Stress, cortisol, and why your gains stalled', 'recovery', 'life stress and training'),
  ('Soreness is not a measure of a good workout', 'recovery', 'DOMS science'),
  ('How to actually build endurance if you only lift', 'conditioning', 'crossover for strength athletes'),
  ('The hip hinge: most-screwed-up movement in the gym', 'mobility', 'patterning + cues'),
  ('Pre-bed protein: real benefit or marketing', 'nutrition', 'casein research'),
  ('Body weight on the bar isn''t the only progress', 'programming', 'tracking what actually matters'),
  ('Why you should care about your VO2 max', 'conditioning', 'cardiorespiratory fitness and lifespan'),
  ('Carbs, performance, and why keto works for some', 'nutrition', 'individual response'),
  ('Programming for two: training when life is chaos', 'programming', 'minimalist approaches'),
  ('Motivation is overrated. Discipline is the lift.', 'mindset', 'the consistency argument'),
  ('The two-week rule: how to actually start (and stay)', 'mindset', 'environment design for habit formation'),
  ('Why you can''t out-train a bad attitude', 'mindset', 'identity-based change'),
  ('The 1% better fallacy', 'mindset', 'why micro-improvements actually compound')
on conflict do nothing;
